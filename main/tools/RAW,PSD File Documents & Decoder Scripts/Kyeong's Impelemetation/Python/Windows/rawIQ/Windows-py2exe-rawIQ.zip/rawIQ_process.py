#!/usr/bin/env python

#This script accepts an uncompressed Microsoft Spectrum Observatory RAW IQ scan file, processes and displays summarized results.
#Note that spectrum observatory scan files are compressed in default. Decompress them with decompress.exe first (.NET / Mono executable).

#Usage : ./rawIQ_process.py target_file (Unix with execute permission)
#         python rawIQ_process.py target_file (Windows or with non-execute permission)
#Requirements: Python 2.7 with Protoc Python bindings (Ubuntu package name: python-protobuf). rawIQ_pb2.py must be present in the same directory.

#See: https://developers.google.com/protocol-buffers/docs/pythontutorial
#(* This source code is heavily based on the example codes present on the above website.)
#Last-modified: Jul 5, 2016 (Kyeong Su Shin)

import sys
import argparse
import rawIQ_pb2
import os.path
import time
import matplotlib.pyplot as plt
import numpy as np
import google.protobuf
import FileDialog
from operator import add

#Print out the "config" section of the data file and call "print_data_block_summary"
#to print out the summarized version of the RAW IQ snapshot blocks.
#input: rawIQ_pb2.RawIqFile()
#output: none (directly prints out to stdout)
def print_rawIQ_summary(rawIQ_read,raw_plot,psd_plot,dump_csv,f_write):

	#Print out station configurations
	print "\n \n \n \n -----------------CONFIG BLOCK-----------------"
	#"replace" statements are not necessary, but they are used to re-format the "HardwareConfiguration" 
	#section of the config metadata (which has \\r, \\n, and \\t instead of their actual ASCII codes).
	print str(rawIQ_read.Config).replace("\\n","\n\t").replace("\\r","").replace("\\t","\t")
	print "---------------CONFIG BLOCK END---------------\n \n \n \n"
	
	#Print out summary of the snapshot data blocks.
	print "--------------DATA BLOCK SUMMARY--------------"
	print_data_block_summary(rawIQ_read,raw_plot,psd_plot,dump_csv,f_write)
	print "------------DATA BLOCK SUMMARY END------------ \n "

#Print out summary of the data blocks.
#input: rawIQ_pb2.RawIqFile()
#output: none (directly prints out to stdout)
def print_data_block_summary(rawIQ_read,raw_plot,psd_plot,dump_csv,f_write):
	cnt = 0							#total data blocks within a file.
	data_cnt_sum = 0				#total data points within a file. (# blocks * data points per block)
	min_time = 9223372036854775807 #earliest timestamp observed. (initialized to int64_max)
	max_time = -1					#latest timestamp value observed.
	min_freq = float("inf")		#minimum snapshot starting frequency observed.
	max_freq = -1					#maximum snapshot stoping frequency observed.
	
	#for each block
	for data_block in rawIQ_read.SpectralIqData:
		#count up
		cnt = cnt + 1

		#print out block information
		#(comment out to reduce amount of information displayed.)
		print "Block " + str(cnt) + " : "
		print "\t timestamp : " + time.ctime(data_block.Time_stamp.value/10000000  + time.altzone)	#Python automatically adjusts the timezone, but that is not desirable. So, roll-back by adding back the time offset  "time.altzone". 
		print "\t Start Freq : " + str((data_block.StartFrequencyHz)/1e6) + "Mhz"
		print "\t Stop Freq : " + str((data_block.StopFrequencyHz)/1e6) + "Mhz"
		print "\t Center Freq : " + str((data_block.CenterFrequencyHz)/1e6) + "Mhz"
		print "\t NmeaGpggaLocation : " + data_block.NmeaGpggaLocation
		print "\t Data count : " + str(len(data_block.DataPoints)/2)

		data_block_i = data_block.DataPoints[::2]
		data_block_q = [x*1j for x in data_block.DataPoints[1::2]]		
		data_block_complex = map(add, data_block_i, data_block_q)
		
		#plot RAW IQ
		if raw_plot == cnt or raw_plot == 0:
			#i component
			plt.plot(np.real(data_block_complex),'b')
			#q component
			plt.plot(np.imag(data_block_complex),'r')
			plt.ylabel('Amplitude')
			plt.title('RAW IQ data plot. Freq:' + str((data_block.CenterFrequencyHz)/1e6) + "Mhz" + ', Timestamp:' + str(data_block.Time_stamp.value))
			#plot
			plt.show()		

		
		#dump to CSV
		if dump_csv == cnt or dump_csv == 0:
			#dump metadata of the snapshot
			f_write.write("Block," + str(cnt) + "\n")
			f_write.write("timestamp," + time.ctime(data_block.Time_stamp.value/10000000  + time.altzone) + "\n")	#Python automatically adjusts the timezone, but that is not desirable. So, roll-back by adding back the time offset  "time.altzone". 
			f_write.write("Start Freq," + str((data_block.StartFrequencyHz)/1e6) + "Mhz" + "\n")
			f_write.write("Stop Freq," + str((data_block.StopFrequencyHz)/1e6) + "Mhz" + "\n")
			f_write.write("Center Freq," + str((data_block.CenterFrequencyHz)/1e6) + "Mhz" + "\n")
			f_write.write("NmeaGpggaLocation," + data_block.NmeaGpggaLocation + "\n")
			f_write.write("Data count," + str(len(data_block.DataPoints)/2) + "\n")
			
			#dump the main IQ data
			#TODO : moar efficient implementation wanted.
			#f_write.write("------DATA STARTS HERE------ \n")
			#f_write.write("\n".join(str(x) for x in data_block_complex))				
			f_write.write("I,Q \n")
			re = np.real(data_block_complex)
			im = np.imag(data_block_complex)
			for i in xrange(0,len(data_block.DataPoints)/2):
				f_write.write(str(re[i])+","+str(im[i])+"\n")

			#add an extra line at the end of the block.
			f_write.write("\n")
	
		#update min/max timestamp, frequency values.
		min_time = min(min_time, data_block.Time_stamp.value)
		max_time = max(max_time, data_block.Time_stamp.value)
		min_freq = min(min_freq, data_block.StartFrequencyHz)
		max_freq = max(max_freq, data_block.StopFrequencyHz)
		
		#increment the total number of data points observed.
		data_cnt_sum = data_cnt_sum + (len(data_block.DataPoints)/2)
	
	#Done with the loop; now print out the overall summary.
	print "\n---------SUMMARY---------------\n"
	print "min_time : " + time.ctime(min_time/10000000 + time.altzone) 
	print "max_time : " + time.ctime(max_time/10000000  + time.altzone) 
	print "min starting freq : " +  str((min_freq)/1e6) + "Mhz"
	print "max stoping freq : " +  str((max_freq)/1e6) + "Mhz"
	print "Total IQ Data points #: " + str(data_cnt_sum)
	print "Total IQ Data points (in bytes): " + str(data_cnt_sum * 8) + "Bytes (" + str((data_cnt_sum * 8)/(1024.0*1024)) + "MiB)"
	print "\n-------------------------------\n"

#--------------------------------------------------
# Main routine (int main() equivalent)
#--------------------------------------------------

#set argument parser
parser = argparse.ArgumentParser()
parser.add_argument("path", help="input file path")
parser.add_argument("-r", "--plot-raw", type=int, nargs='?', const=-1, help="Plot RAW IQ Data at (PLOT_RAW)th snapshot. Prints out every snapshots if setted zero.")
parser.add_argument("-d", "--dump-csv", type=int, nargs='?', const=-1, help="Dumps (DUMP_CSV)th snapshot data to a CSV file. Name of the generated snapshot file is equal to the name of the input file with .csv appended at the end. Dumps out every snapshots if setted zero.")

args=parser.parse_args()

#open file.
f = open(args.path,"rb");


#make a CSV file if necessary.
if args.dump_csv >= 0:
	f_write = open(args.path+".csv","w");
else:
	f_write = "";

#read and close file.
rawIQ_read = rawIQ_pb2.RawIqFile()
rawIQ_read.ParseFromString(f.read())
f.close()

#process.
print_rawIQ_summary(rawIQ_read,args.plot_raw,-1,args.dump_csv,f_write)

#close the csv dump file.
if args.dump_csv >= 0:
	f_write.close()
