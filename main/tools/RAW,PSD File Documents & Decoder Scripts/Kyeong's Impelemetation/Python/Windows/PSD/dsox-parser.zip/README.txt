Dependencies:

-.NET runtime
-VC 2008 Redistributable

(Most Windows machines will have them already, but try installing them if it does not work.)

Usage:
decompress.exe filename.dsox (to decompress the file - parser.bat will not take the compressed version.)
parser.bat -r 2 filename.dsox.uncompressed (to plot 2th block in the file)
parser.bat -c 3 filename.dsox.uncompressed (to dump 3rd block in the file to a csv file)
parser.bat -c 0 filename.dsox.uncompressed (to dump all block in the file to a csv file. Warning - it WILL result a large CSV file.)

The program can be slow (may take a few minutes) when the input file is large. 